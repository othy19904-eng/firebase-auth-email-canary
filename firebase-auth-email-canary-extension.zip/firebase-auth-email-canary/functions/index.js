'use strict';

const { runCanary, sendWebhook } = require('./lib');

exports.scheduledCanary = async () => {
  const apiKey = String(process.env.WEB_API_KEY || '').trim();
  const webhookUrl = String(process.env.ALERT_WEBHOOK_URL || '').trim();

  if (!apiKey) {
    const result = {
      status: 'failed',
      diagnosis: 'FIREBASE_CONFIG_OR_AUTH_API_FAILURE',
      confidence: 'high',
      summary: 'WEB_API_KEY is not configured for this extension instance.',
      stages: [],
      timings: {},
    };
    console.error(JSON.stringify({ event: 'firebase_auth_email_canary', ...result }));
    if (webhookUrl) {
      try {
        await sendWebhook(fetch, webhookUrl, result);
      } catch (err) {
        console.error('Webhook alert failed', err);
      }
    }
    return result;
  }

  const result = await runCanary({ apiKey });
  const record = {
    event: 'firebase_auth_email_canary',
    timestamp: new Date().toISOString(),
    ...result,
  };

  if (result.diagnosis === 'HEALTHY') {
    console.log(JSON.stringify(record));
  } else {
    console.error(JSON.stringify(record));
    if (webhookUrl) {
      try {
        const webhook = await sendWebhook(fetch, webhookUrl, result);
        console.log(JSON.stringify({ event: 'firebase_auth_email_canary_webhook', ...webhook }));
      } catch (err) {
        console.error('Webhook alert failed', err);
      }
    }
  }

  return result;
};
