'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { extractOobCode, firebaseError, webhookPayload } = require('./lib');

test('extractOobCode finds a Firebase action code in a URL', () => {
  const code = extractOobCode({
    text: 'Verify: https://example.test/action?mode=verifyEmail&oobCode=abc123&apiKey=x',
  });
  assert.equal(code, 'abc123');
});

test('extractOobCode decodes HTML ampersands', () => {
  const code = extractOobCode({
    html: ['<a href="https://example.test/action?mode=verifyEmail&amp;oobCode=z9Y_7&amp;apiKey=x">Verify</a>'],
  });
  assert.equal(code, 'z9Y_7');
});

test('firebaseError returns nested Firebase message', () => {
  assert.equal(firebaseError({ error: { message: 'OPERATION_NOT_ALLOWED' } }), 'OPERATION_NOT_ALLOWED');
});

test('Slack webhook payload uses text', () => {
  const payload = webhookPayload('https://hooks.slack.com/services/a/b/c', {
    diagnosis: 'FIREBASE_TRIGGER_FAILURE',
    confidence: 'high',
    summary: 'Trigger failed',
  });
  assert.match(payload.body, /"text"/);
  assert.match(payload.body, /FIREBASE_TRIGGER_FAILURE/);
});

test('generic webhook payload carries structured event', () => {
  const payload = webhookPayload('https://example.com/hook', {
    diagnosis: 'ACTION_LINK_FAILURE',
    confidence: 'high',
    summary: 'Bad code',
  });
  const parsed = JSON.parse(payload.body);
  assert.equal(parsed.event, 'firebase_auth_email_canary_failure');
  assert.equal(parsed.diagnosis, 'ACTION_LINK_FAILURE');
});
