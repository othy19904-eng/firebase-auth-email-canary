'use strict';

function now() {
  return Date.now();
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomPart() {
  return Math.random().toString(36).slice(2, 12);
}

async function requestJson(fetchImpl, url, init = {}) {
  const response = await fetchImpl(url, init);
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  return { ok: response.ok, status: response.status, data };
}

function firebaseError(data) {
  if (!data || typeof data !== 'object') return 'UNKNOWN_FIREBASE_ERROR';
  return data.error && data.error.message ? data.error.message : 'UNKNOWN_FIREBASE_ERROR';
}

function decodeHtml(value) {
  return String(value || '')
    .replace(/&amp;/g, '&')
    .replace(/&#x3D;/g, '=')
    .replace(/&quot;/g, '"');
}

function extractOobCode(message) {
  const html = Array.isArray(message && message.html) ? message.html : [];
  const joined = decodeHtml([message && message.text ? message.text : '', ...html].join('\n'));
  const urls = joined.match(/https?:\/\/[^\s"'<>]+/g) || [];

  for (const raw of urls) {
    try {
      const url = new URL(raw);
      const code = url.searchParams.get('oobCode');
      if (code) return code;
    } catch {
      // Ignore malformed URLs and keep looking.
    }
  }

  const direct = joined.match(/[?&]oobCode=([^&\s"'<>]+)/);
  return direct ? decodeURIComponent(direct[1]) : null;
}

function webhookPayload(url, result) {
  const text = `Firebase Auth Email Canary: ${result.diagnosis} (${result.confidence} confidence) — ${result.summary}`;
  let host = '';
  try {
    host = new URL(url).hostname.toLowerCase();
  } catch {
    return { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(result) };
  }

  if (host === 'hooks.slack.com') {
    return { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) };
  }

  if (host === 'discord.com' || host === 'discordapp.com') {
    return { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text }) };
  }

  return {
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ event: 'firebase_auth_email_canary_failure', ...result }),
  };
}

async function sendWebhook(fetchImpl, webhookUrl, result) {
  if (!webhookUrl) return { sent: false, reason: 'not_configured' };
  const payload = webhookPayload(webhookUrl, result);
  const response = await fetchImpl(webhookUrl, { method: 'POST', ...payload });
  return { sent: response.ok, status: response.status };
}

async function runCanary({ apiKey, fetchImpl = fetch, waitImpl = wait, maxAttempts = 12, pollMs = 1500 }) {
  const stages = [];
  const timings = {};
  let inboxToken = '';
  let inboxAccountId = '';
  let testEmail = '';
  let firebaseIdToken = '';

  const finish = (diagnosis, confidence, summary, status = 'failed') => ({
    status,
    diagnosis,
    confidence,
    summary,
    testEmail,
    stages,
    timings,
  });

  try {
    let started = now();
    const domains = await requestJson(fetchImpl, 'https://api.mail.tm/domains?page=1');
    const members = domains.data && domains.data['hydra:member'];
    const domain = Array.isArray(members) && members[0] ? members[0].domain : null;
    if (!domains.ok || !domain) {
      stages.push({ name: 'Test inbox', ok: false, detail: 'Could not obtain a disposable inbox domain.' });
      return finish('TEST_INFRA_FAILURE', 'high', 'The temporary inbox provider failed before Firebase was tested.');
    }

    testEmail = `firebase-canary-${randomPart()}@${domain}`;
    const inboxPassword = `C-${randomPart()}-${randomPart()}!`;
    const account = await requestJson(fetchImpl, 'https://api.mail.tm/accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ address: testEmail, password: inboxPassword }),
    });
    if (!account.ok) {
      stages.push({ name: 'Test inbox', ok: false, detail: `Inbox account creation failed (${account.status}).` });
      return finish('TEST_INFRA_FAILURE', 'high', 'The temporary inbox could not be created, so Firebase was not tested.');
    }
    inboxAccountId = account.data && account.data.id ? account.data.id : '';

    const token = await requestJson(fetchImpl, 'https://api.mail.tm/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ address: testEmail, password: inboxPassword }),
    });
    inboxToken = token.data && token.data.token ? token.data.token : '';
    timings.inboxSetupMs = now() - started;
    if (!token.ok || !inboxToken) {
      stages.push({ name: 'Test inbox', ok: false, detail: 'Inbox token creation failed.' });
      return finish('TEST_INFRA_FAILURE', 'high', 'The temporary inbox could not be authenticated, so Firebase was not tested.');
    }
    stages.push({ name: 'Test inbox', ok: true, detail: 'Temporary inbox created and authenticated.' });

    started = now();
    const firebasePassword = `F-${randomPart()}-${randomPart()}!aA1`;
    const signup = await requestJson(
      fetchImpl,
      `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: testEmail, password: firebasePassword, returnSecureToken: true }),
      }
    );
    timings.signupMs = now() - started;
    if (!signup.ok) {
      const code = firebaseError(signup.data);
      stages.push({ name: 'Firebase signup', ok: false, detail: code });
      return finish('FIREBASE_CONFIG_OR_AUTH_API_FAILURE', 'high', `Firebase rejected temporary user creation: ${code}`);
    }
    firebaseIdToken = signup.data && signup.data.idToken ? signup.data.idToken : '';
    stages.push({ name: 'Firebase signup', ok: true, detail: 'Temporary Firebase Auth user created.' });

    started = now();
    const trigger = await requestJson(
      fetchImpl,
      `https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestType: 'VERIFY_EMAIL', idToken: firebaseIdToken }),
      }
    );
    timings.triggerMs = now() - started;
    if (!trigger.ok) {
      const code = firebaseError(trigger.data);
      stages.push({ name: 'Auth email trigger', ok: false, detail: code });
      return finish('FIREBASE_TRIGGER_FAILURE', 'high', `Firebase failed before email delivery: ${code}`);
    }
    stages.push({ name: 'Auth email trigger', ok: true, detail: 'Firebase accepted VERIFY_EMAIL.' });

    started = now();
    let received = null;
    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      const list = await requestJson(fetchImpl, 'https://api.mail.tm/messages?page=1', {
        headers: { Authorization: `Bearer ${inboxToken}` },
      });
      const messageList = list.data && list.data['hydra:member'];
      if (Array.isArray(messageList) && messageList.length > 0) {
        const full = await requestJson(fetchImpl, `https://api.mail.tm/messages/${messageList[0].id}`, {
          headers: { Authorization: `Bearer ${inboxToken}` },
        });
        if (full.ok) received = full.data;
        break;
      }
      await waitImpl(pollMs);
    }
    timings.waitMs = now() - started;

    if (!received) {
      stages.push({ name: 'Inbox delivery', ok: false, detail: 'No Firebase message arrived within the observation window.' });
      return finish(
        'EMAIL_DELIVERY_FAILURE_OR_TEST_INBOX',
        'medium',
        'Firebase accepted the email trigger, but the test inbox observed no message. The end-to-end path failed, but this alone does not isolate Firebase from the inbox provider.'
      );
    }
    stages.push({
      name: 'Inbox delivery',
      ok: true,
      detail: received.subject ? `Received: ${received.subject}` : 'Firebase message received.',
    });

    const oobCode = extractOobCode(received);
    if (!oobCode) {
      stages.push({ name: 'Action code', ok: false, detail: 'Email arrived, but no oobCode could be extracted.' });
      return finish('MALFORMED_AUTH_EMAIL', 'high', 'The Firebase email arrived, but it did not contain a usable verification action code.');
    }

    started = now();
    const confirm = await requestJson(
      fetchImpl,
      `https://identitytoolkit.googleapis.com/v1/accounts:update?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ oobCode }),
      }
    );
    timings.actionValidationMs = now() - started;
    if (!confirm.ok) {
      const code = firebaseError(confirm.data);
      stages.push({ name: 'Action code', ok: false, detail: code });
      return finish('ACTION_LINK_FAILURE', 'high', `The email arrived, but Firebase rejected its action code: ${code}`);
    }
    stages.push({ name: 'Action code', ok: true, detail: 'Firebase accepted the received oobCode.' });

    return finish(
      'HEALTHY',
      'high',
      'The complete Firebase Auth email path passed: temporary user creation, VERIFY_EMAIL trigger, inbox delivery, and action-code validation.',
      'passed'
    );
  } catch (err) {
    return finish('TEST_RUNTIME_FAILURE', 'high', err instanceof Error ? err.message : 'Unexpected canary failure.');
  } finally {
    if (firebaseIdToken && apiKey) {
      try {
        await requestJson(
          fetchImpl,
          `https://identitytoolkit.googleapis.com/v1/accounts:delete?key=${encodeURIComponent(apiKey)}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idToken: firebaseIdToken }),
          }
        );
      } catch (cleanupError) {
        console.warn('Firebase cleanup failed', cleanupError);
      }
    }

    if (inboxToken && inboxAccountId) {
      try {
        await fetchImpl(`https://api.mail.tm/accounts/${inboxAccountId}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${inboxToken}` },
        });
      } catch (cleanupError) {
        console.warn('Inbox cleanup failed', cleanupError);
      }
    }
  }
}

module.exports = {
  extractOobCode,
  firebaseError,
  runCanary,
  sendWebhook,
  webhookPayload,
};
